

#include <iostream>


using namespace std;

int main()
{
	std::cout << " Hello world ! " << std::endl;

	return 1;
}